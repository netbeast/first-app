# get-started
A repo with code about how to make simple xway apps.

Apps for xway are based on Javascript. That means you can program applications as you would do for a web app with nodejs.

Go to npmjs.org or nodejs.org for further documentation by the moment. We will
keep updated this repo!
